"use strict"

let users = [{username : "gamik" , password : "gamik"},{username: "rupesh" , password: "rupesh"},{ username: "shweta", password:"shweta"}];
users = JSON.stringify(users);
sessionStorage.setItem('users_our', users); //storing users in browsers storage

$(document).ready(function () {

    $( "#login_content" ).tabs(); //using tabs widgets 

    $("#login").click(function () { 
        let username = $("#username_value").val().trim();
        let password = $("#password_value").val().trim();

        users = JSON.parse(sessionStorage.getItem('users_our')); //retreving users from browser storage
        
        if (users.some(e => e.username === username && e.password === password)) {
            let user = {username: username,password: password};
            user = JSON.stringify(user);
            sessionStorage.setItem("user_logged",user); 
            window.location = "index.html";
          }
          else{
              alert("please enter correct details");
          }

    });

    $("#signup").click(function () { 
        let username = $("#username_value_reg").val().trim();
        let password = $("#password_value_reg").val().trim();
        let password2 = $("#password_valRE_reg").val().trim();

        if(username != "" && password != "" && password2 !=""){
            if(password == password2){
                let user = {username: username , password: password};
                let users = JSON.parse(sessionStorage.getItem('users_our'));
                users.push(user);
              //  console.log(users);
                users = JSON.stringify(users);
                sessionStorage.setItem("users_our" , users);
                alert("User signed up successfully.");
                $("#username_value_reg").val("");
                $("#password_value_reg").val("");
                $("#password_valRE_reg").val("");
            }else{
                alert("passwords do not match");
                
            }
        }else{
            alert("please enter correct values");
            $("#username_value_reg").val("");
            $("#password_value_reg").val("");
            $("#password_valRE_reg").val("");
        }

        
        
        

    });
});