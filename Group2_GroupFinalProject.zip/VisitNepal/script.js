"use strict";


$(document).ready( () => {
    dateTop();
    //checking who has logged in
    let user = JSON.parse(sessionStorage.getItem("user_logged"));
    if(user != null){ 
        $(".signin").text(user.username);
    }

});

// live date and time
const dateTop = () => {
    let options = {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "numeric",
      minute: "numeric",
      second: "numeric",
    };
    let date = new Date().toLocaleString("en-US", options); // get current date and time
    $("#time").text(date);
  
    setInterval(() => {
      date = new Date().toLocaleString("en-US", options); // get current date and time
      $("#time").text(date);
    }, 1000);
  };

