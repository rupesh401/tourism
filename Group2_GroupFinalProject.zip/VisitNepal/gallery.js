"use strict"

$(document).ready(function () {
    
    jQuery("#gallery").unitegallery(
        {gallery_theme:"tiles"	,
        tiles_type:"nested"}
    ); 
});