"use strict";
// jquery accordian widgets 
$(document).ready( () => {
    var icons = {
        header: "ui-icon-circle-arrow-e",
        activeHeader: "ui-icon-circle-arrow-s"
      };
    $( "#vlogs" ).accordion({
        collapsible: true
    });  
    $( "#toggle" ).button().on( "click", function() {
        if ( $( "#vlogs" ).accordion( "option", "icons" ) ) {
          $( "#vlogs" ).accordion( "option", "icons", null );
        } else {
          $( "#vlogs" ).accordion( "option", "icons", icons );
        }
      });
});